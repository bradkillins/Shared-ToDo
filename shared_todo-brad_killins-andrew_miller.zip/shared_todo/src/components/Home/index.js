import React from "react";
import "./index.css";

const Home = () => {
  return (
    <div className="home">
      <h1>Welcome to Shared To-Dos!</h1>
      <p>Some wonderful text here to describe our app!</p>
    </div>
  );
};

export default Home;
